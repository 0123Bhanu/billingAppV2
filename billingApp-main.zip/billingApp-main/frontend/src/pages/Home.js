import React from 'react'

export default function home() {
  return (
    <div>
      <h1>Welcome Admin!!!</h1>
    </div>
  )
}
